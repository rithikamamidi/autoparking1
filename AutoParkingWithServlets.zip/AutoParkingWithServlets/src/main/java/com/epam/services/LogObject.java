package com.epam.services;

import java.time.LocalTime;
/** log object in database.
 * @author Rithika_Mamidi
 *
 */
public class LogObject extends TransactionObject {
    /** out time of vehicle.
     */
    private LocalTime outTime;
    /**constructor.
     * @param vehicleNumber1 vehicle number
     * @param slotNumber1 slot number
     * @param inTime1 vehicle in time
     * @param outTime1 vehicle out time
     */

    LogObject(final String vehicleNumber1, final int slotNumber1,
            final LocalTime inTime1, final LocalTime outTime1) {
        super(vehicleNumber1, slotNumber1, inTime1);
        this.outTime = outTime1;
    }
    /** set vehicle out time.
     * @param outTime1 vehicle out time
     */
    protected void setOutTime(final LocalTime outTime1) {
        this.outTime = outTime1;
    }
    /** get vehicle out time.
     * @return vehicle out time
     */
    protected LocalTime getOutTime() {
        return outTime;
    }
}
