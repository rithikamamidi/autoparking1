package com.epam.services;


import java.sql.SQLException;
import java.time.LocalTime;

import java.util.ArrayList;

import java.util.Map;

import com.epam.persistence.DatabaseOperations;



/** class contains all the methods to perform operations with file.
 * @author Rithika_Mamidi
 */
public class TransactionOperations {
    /** database operations object.
     */
    private DatabaseOperations databaseOperationsObject = new DatabaseOperations();
    /**stores data in transaction db.
     * @param carNumber vehicle number
     * @param slotNumber slot number of vehicle in parking lot
     * @param inTime in time of the vehicle
     * @throws SQLException sql exception
     */
    public void insert(final String carNumber,
            final int slotNumber,
          final LocalTime inTime) throws SQLException {
          String[] data = {carNumber, Integer.toString(slotNumber), inTime.toString()};
          databaseOperationsObject.insertData("transaction", data);
    }
    /** This method reads data from csv file and stores it in hash map.
     * @param occupiedVehicleNumberAndSlots vehicle number-slot number
     * and in time
     * @throws SQLException sql exception
     */
    public void readData(final Map<String, Slot>
            occupiedVehicleNumberAndSlots) throws SQLException {
        ArrayList<String[]> contentRead;
        contentRead = databaseOperationsObject.readData("transaction");
        for (String[] dataRow : contentRead) {
            Slot slot = new Slot(Integer.parseInt(dataRow[1]),
                   LocalTime.parse(dataRow[2]));
            occupiedVehicleNumberAndSlots.put(dataRow[0], slot);
        }
    }
    /** This method deletes the row corresponding to the vehicle
     *  number which is un parked.
     * @param carNumber vehicle number of the un parked vehicle.
     * @throws SQLException sql exception
     */
    public void deleteRowWithVehicleNumber(final String carNumber) throws SQLException {
        databaseOperationsObject.deleteRow("transaction" , carNumber);
    }
}
