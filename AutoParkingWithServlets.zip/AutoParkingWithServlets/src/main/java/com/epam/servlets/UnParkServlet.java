package com.epam.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.services.GetData;
import com.epam.services.Slot;
import com.epam.services.UnPark;

@WebServlet(urlPatterns = "/unparkServlet")
public class UnParkServlet extends HttpServlet {
	/** This hash map stores the vehicle number and the
     *  slot that it is parked in. */
    Map<String, Slot> occupiedVehicleNumberAndSlots =
               new HashMap<String, Slot>();
    /** This array list stores the vacant slot numbers.  */
    List<Integer> vacantSlotNumbers
                         = new LinkedList<Integer>();
    final int ten = 10;
    int numberOfSlots = ten;
	@Override
    protected void doPost(final HttpServletRequest request,
            final HttpServletResponse response)
                    throws IOException, ServletException {
		String vehicleNumber = request.getParameter("vehicleNumber");
		GetData getDataObject = new GetData();
		try {
			getDataObject.getData(vacantSlotNumbers,
					numberOfSlots, occupiedVehicleNumberAndSlots);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		UnPark unparkObject = new UnPark();
		String output = unparkObject.unPark(vehicleNumber,
				vacantSlotNumbers,
				occupiedVehicleNumberAndSlots);
		PrintWriter printWriter = response.getWriter();
        printWriter.println(output);
    }


}
