package com.epam.servlets;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.services.Admin;
/** web servlet.
 * @author Rithika_Mamidi
 */
@WebServlet(urlPatterns = "/adminLogin")
public class AdminLoginPage extends HttpServlet {
    /** displays the login page to admin.
     */
    @Override
    protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response)
            throws IOException, ServletException {
    }
    /** checks if admin is valid.
     */
    @Override
    protected void doPost(final HttpServletRequest request,
            final HttpServletResponse response)
                    throws IOException, ServletException {
        Admin admin = new Admin("admin", "admin");
        String userName = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        if (userName.equals(admin.getUserName())
                &&    password.equals(admin.getPassword())) {
            response.sendRedirect("ParkVehicle.jsp");
        } else if (userName.equals("admin2")
                &&    password.equals("admin2")) {
            response.sendRedirect("UnParkVehicle.jsp");
        } else {
            PrintWriter printWriter = response.getWriter();
            printWriter.println("Invalid user!");
        }
    }

}
