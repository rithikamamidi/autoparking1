package com.epam.persistence;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


/** data base operations.
 * @author Rithika_Mamidi
 *
 */
public class DatabaseOperations {
    /** get connection to database.
     * @return connection
     */
    public Connection getConnection() {
        /**connection to database.
         */
        Connection connection = null;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/autoparking";
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(
                    url, "root", "root");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }
    /** adds the row to the database.
     * @param tableName table name.
     * @return string array arraylist
     * @throws SQLException sql exception
     */
    public ArrayList<String[]> readData(final String tableName)
          throws SQLException {
        final int three = 3;
        ArrayList<String[]> transactionData = new ArrayList<String[]>();
        try (Connection connection = getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(
                        "select * from transaction;")) {
                while (resultSet.next()) {
                String[] rowRead = new String[] {
                        resultSet.getString(1),
                        Integer.toString(
                           resultSet.getInt(2)),
                        resultSet.getString(three)};
                transactionData.add(rowRead);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactionData;
    }
    /** inserts data to the table in database.
     * @param data data to be inserted
     * @param tableName table name
     * @throws SQLException sql exception
     */
    public void insertData(final String tableName, final String[] data)
           throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement =
                 createPreparedStatement(connection, data, "transaction")) {
            preparedStatement.executeUpdate();
        }
    }
    /** insert data into table.
     * @param connection db connection
     * @param data data to be stored
     * @param tableName table name in which we have to store
     * @return prepared statement
     * @throws SQLException sql exception
     */
    public PreparedStatement createPreparedStatement(
            final Connection connection,
            final String[] data, final String tableName)
                    throws SQLException {
        final int three = 3;
        String query = "insert into " + tableName + " values (?, ?, ?)";
        PreparedStatement preparedStatement =
                connection.prepareStatement(query);
        preparedStatement.setString(1,  data[0]);
        preparedStatement.setInt(2,  Integer.parseInt(data[1]));
        preparedStatement.setString(three,  data[2]);
        return preparedStatement;
    }
    /** deletes a row from mysql database.
     * @param tableName table name
     * @param vehicleNumber vehicle number
     * @throws SQLException sql exception
     */
    public void deleteRow(final String tableName, final String vehicleNumber)
           throws SQLException {
        String query = "delete from " + tableName
              + " where vehiclenumber='" + vehicleNumber + "'";
        try (Connection connection = getConnection();
        Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        }
    }
}
