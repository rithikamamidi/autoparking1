package com.epam.services;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class GetData {
        final int ten = 10;
        final int three = 3;
        String output = "";
    void findVacantSlots(
             final List<Integer> vacantSlotNumbers,
             final int numberOfSlots, final Map<String,
             Slot> occupiedVehicleNumberAndSlots) throws SQLException {
        TransactionOperations transactionOperations =
                new TransactionOperations();
        transactionOperations.readData(
                occupiedVehicleNumberAndSlots);
        int[] slotNumbers = new int[numberOfSlots];
        for (int index = 0; index < numberOfSlots; index++) {
            slotNumbers[index] = 0;
        }
        Collection<Slot> slotValues = occupiedVehicleNumberAndSlots.values();
        for (Slot slot : slotValues) {
            slotNumbers[(slot.getSlotNumber()) - 1] = 1;
        }
        for (int index = 0; index < numberOfSlots; index++) {
            if (slotNumbers[index] == 0) {
                vacantSlotNumbers.add(index + 1);
            }
        }
    }
    public void getData(final List<Integer> vacantSlotNumbers,
            final int numberOfSlots, final Map<String,
            Slot> occupiedVehicleNumberAndSlots) throws SQLException {
    	TransactionOperations transacOperations = new TransactionOperations();
    	transacOperations.readData(occupiedVehicleNumberAndSlots);
    	findVacantSlots(vacantSlotNumbers,
                numberOfSlots, occupiedVehicleNumberAndSlots); 	
    }

}
