package com.epam.services;

import java.time.LocalTime;

/** transaction object in database.
 * @author Rithika_Mamidi
 */
public class TransactionObject {
    /** vehicle number.
     */
    private String vehicleNumber;
    /** slot number.
     */
    private int slotNumber;
    /** in time.
     */
    private LocalTime inTime;
    /** constructor.
     * @param vehicleNumber1 vehicle number
     * @param slotNumber1 slot number
     * @param inTime1 in time
     */
    TransactionObject(final String vehicleNumber1,
            final int slotNumber1, final LocalTime inTime1) {
        this.vehicleNumber = vehicleNumber1;
        this.slotNumber = slotNumber1;
        this.inTime = inTime1;
    }
    /** set vehicle number.
     * @param vehicleNumber1 vehicle number
     */
    protected void setVehicleNumber(final String vehicleNumber1) {
        this.vehicleNumber = vehicleNumber1;
    }
    /** set slot number.
     * @param slotNumber1 slot number
     */
    protected void setSlotNumber(final int slotNumber1) {
        this.slotNumber = slotNumber1;
    }
    /** set vehicle in time.
     * @param inTime1 vehicle in time
     */
    protected void setInTime(final LocalTime inTime1) {
        this.inTime = inTime1;
    }
    /** get vehicle number.
     * @return vehicle number
     */
    protected String getVehicleNumber() {
        return vehicleNumber;
    }
    /** get slot number.
     * @return slot number
     */
    protected int getSlotNumber() {
        return slotNumber;
    }
    /** get vehicle in time.
     * @return vehicle in time
     */
    protected LocalTime getInTime() {
        return inTime;
    }
}
