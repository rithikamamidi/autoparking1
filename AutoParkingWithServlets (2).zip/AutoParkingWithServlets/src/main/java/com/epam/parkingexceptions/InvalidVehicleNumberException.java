package com.epam.parkingexceptions;
/** exception when vehicle number is invalid.
 * @author Rithika_Mamidi
 */
public class InvalidVehicleNumberException extends Exception {
    /** exception when vehicle number is invalid.
     * @param exception exception string
     */
    public InvalidVehicleNumberException(final String exception) {
        super(exception);
    }


}
